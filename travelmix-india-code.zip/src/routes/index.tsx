import { createFileRoute, Link } from "@tanstack/react-router";
import { Layers, Sparkles } from "lucide-react";
import { z } from "zod";
import { SiteHeader } from "@/components/SiteHeader";
import { SearchForm } from "@/components/SearchForm";
import { RouteCard } from "@/components/RouteCard";
import { generateRoutes } from "@/lib/mock-routes";

const searchSchema = z.object({
  from: z.string().default("Pune"),
  to: z.string().default("Bangalore"),
  date: z.string().default(""),
});

export const Route = createFileRoute("/")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "TravelMix India — Find the best way to travel anywhere in India" },
      { name: "description", content: "Compare flights, trains, buses and carpools between any two Indian cities. Cheapest, fastest and recommended routes in one place." },
      { property: "og:title", content: "TravelMix India" },
      { property: "og:description", content: "Compare flights, trains, buses and carpools across India." },
    ],
  }),
  component: Home,
});

function Home() {
  const { from, to, date } = Route.useSearch();
  const routes = generateRoutes(from, to);

  const cheapest = routes.find((r) => r.kind === "cheapest");
  const fastest = routes.find((r) => r.kind === "fastest");
  const recommended = routes.find((r) => r.kind === "recommended");
  const alternates = routes.filter((r) => r.kind === "alternate");

  const formattedDate = date
    ? new Date(date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" })
    : "Any date";

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[var(--gradient-hero)]" />
        <div
          className="absolute inset-0 -z-10 opacity-20"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, white 1px, transparent 1px), radial-gradient(circle at 80% 60%, white 1px, transparent 1px)",
            backgroundSize: "40px 40px, 60px 60px",
          }}
        />
        <div className="container mx-auto px-4 pb-10 pt-12 md:pb-14 md:pt-20">
          <div className="mx-auto max-w-3xl text-center text-primary-foreground">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" /> Smart routing across India
            </span>
            <h1 className="mt-5 text-3xl font-bold leading-tight md:text-5xl">
              Travel India the <span className="text-[var(--saffron)]">smart</span> way
            </h1>
            <p className="mx-auto mt-3 max-w-xl text-sm text-white/85 md:text-base">
              Compare flights, trains, buses and carpools — find the cheapest, fastest and best-recommended routes instantly.
            </p>
          </div>

          <div className="mx-auto mt-8 max-w-5xl">
            <SearchForm />
          </div>
        </div>
      </section>

      <main className="container mx-auto px-4 py-8 md:py-12">
        <div className="mb-6 flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <h2 className="text-2xl font-bold md:text-3xl">
            {from} <span className="text-muted-foreground">→</span> {to}
          </h2>
          <span className="text-sm text-muted-foreground">{formattedDate}</span>
        </div>

        <section>
          <h3 className="mb-4 text-lg font-semibold md:text-xl">Top picks for you</h3>
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {recommended && <RouteCard route={recommended} highlight />}
            {cheapest && <RouteCard route={cheapest} />}
            {fastest && <RouteCard route={fastest} />}
          </div>
        </section>

        {alternates.length > 0 && (
          <section className="mt-12">
            <div className="mb-4 flex items-center gap-2">
              <Layers className="h-5 w-5 text-primary" />
              <h3 className="text-lg font-semibold md:text-xl">Alternate routes</h3>
              <span className="text-sm text-muted-foreground">({alternates.length} options)</span>
            </div>
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {alternates.map((r) => (
                <RouteCard key={r.id} route={r} />
              ))}
            </div>
          </section>
        )}
      </main>

      <footer className="border-t border-border">
        <div className="container mx-auto flex flex-col items-center justify-between gap-2 px-4 py-6 text-sm text-muted-foreground md:flex-row">
          <p>© {new Date().getFullYear()} TravelMix India</p>
          <p>
            Sample data shown for demo purposes. <Link to="/" className="underline">Reset</Link>
          </p>
        </div>
      </footer>
    </div>
  );
}
