export type TransportMode = "flight" | "train" | "bus" | "carpool";

export interface RouteSegment {
  mode: TransportMode;
  operator: string;
  from: string;
  to: string;
  duration: string;
}

export interface RouteOption {
  id: string;
  kind: "cheapest" | "fastest" | "recommended" | "alternate";
  title: string;
  summary: string;
  price: number;
  duration: string;
  durationMins: number;
  modes: TransportMode[];
  segments: RouteSegment[];
}

export const popularCities = [
  "Mumbai", "Delhi", "Bengaluru", "Chennai", "Kolkata", "Hyderabad",
  "Pune", "Ahmedabad", "Jaipur", "Goa", "Kochi", "Lucknow",
  "Chandigarh", "Indore", "Bhopal", "Varanasi", "Agra", "Udaipur",
];

function fmtDuration(mins: number) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

export function generateRoutes(from: string, to: string): RouteOption[] {
  const seed = (from.length + to.length) || 8;
  const f = from || "Source";
  const t = to || "Destination";
  const mid = "Nagpur";
  const mid2 = "Vadodara";

  const routes: RouteOption[] = [
    {
      id: "cheapest",
      kind: "cheapest",
      title: "Cheapest Route",
      summary: `Budget-friendly mix of bus and carpool from ${f} to ${t}. Ideal if you have time to spare.`,
      price: 1199 + seed * 3,
      duration: fmtDuration(1080),
      durationMins: 1080,
      modes: ["bus", "carpool"],
      segments: [
        { mode: "bus", operator: "VRL Travels (Sleeper)", from: f, to: mid, duration: "12h 00m" },
        { mode: "carpool", operator: "BlaBlaCar Share", from: mid, to: t, duration: "6h 00m" },
      ],
    },
    {
      id: "fastest",
      kind: "fastest",
      title: "Fastest Route",
      summary: `Direct non-stop flight from ${f} to ${t}. Reach in the shortest time possible.`,
      price: 6299 + seed * 25,
      duration: fmtDuration(150),
      durationMins: 150,
      modes: ["flight"],
      segments: [
        { mode: "flight", operator: "Vistara UK-945", from: f, to: t, duration: "2h 30m" },
      ],
    },
    {
      id: "recommended",
      kind: "recommended",
      title: "Recommended Route",
      summary: `Best balance of cost and travel time. Comfortable train with a quick carpool transfer.`,
      price: 2499 + seed * 8,
      duration: fmtDuration(540),
      durationMins: 540,
      modes: ["train", "carpool"],
      segments: [
        { mode: "train", operator: "Rajdhani Express 12951", from: f, to: mid2, duration: "8h 00m" },
        { mode: "carpool", operator: "Quick Ride Pool", from: mid2, to: t, duration: "1h 00m" },
      ],
    },
    {
      id: "alt-1",
      kind: "alternate",
      title: "Flight + Carpool",
      summary: `Fly to ${mid2}, then carpool to ${t}. Great when direct flights are full.`,
      price: 4899 + seed * 15,
      duration: fmtDuration(255),
      durationMins: 255,
      modes: ["flight", "carpool"],
      segments: [
        { mode: "flight", operator: "IndiGo 6E-203", from: f, to: mid2, duration: "2h 45m" },
        { mode: "carpool", operator: "Ola Outstation", from: mid2, to: t, duration: "1h 30m" },
      ],
    },
    {
      id: "alt-2",
      kind: "alternate",
      title: "Train + Bus",
      summary: `Overnight train to ${mid} and an AC bus onward to ${t}.`,
      price: 1850 + seed * 5,
      duration: fmtDuration(900),
      durationMins: 900,
      modes: ["train", "bus"],
      segments: [
        { mode: "train", operator: "Shatabdi Express 12001", from: f, to: mid, duration: "9h 00m" },
        { mode: "bus", operator: "RedBus Volvo AC", from: mid, to: t, duration: "6h 00m" },
      ],
    },
    {
      id: "alt-3",
      kind: "alternate",
      title: "Direct Bus",
      summary: `Single long-haul Volvo AC sleeper bus from ${f} to ${t}. No transfers.`,
      price: 1599 + seed * 4,
      duration: fmtDuration(990),
      durationMins: 990,
      modes: ["bus"],
      segments: [
        { mode: "bus", operator: "Orange Travels Sleeper", from: f, to: t, duration: "16h 30m" },
      ],
    },
  ];

  return routes;
}
